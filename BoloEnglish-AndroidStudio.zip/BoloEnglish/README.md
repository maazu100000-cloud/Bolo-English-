# Bolo English — Android App

Ye ek native Android Studio project hai jo aapki `BoloEnglish.html` file ko
WebView ke andar load karta hai (asset `app/src/main/assets/index.html`).
GitHub Actions workflow already add hai jo:

- **Har push par** → Debug APK banata hai (bina signing ke, seedha install ho jati hai)
- **Tag (`v1.0` waghera) push karne par ya "Run workflow" se manual trigger karne par** → Signed Release APK banata hai aur GitHub Release mein attach kar deta hai

## 1. GitHub par upload

1. GitHub par ek naya repo banayein (e.g. `bolo-english-app`).
2. Is zip ke andar ka **poora content** (root ki tamam files/folders — `app/`,
   `gradle/`, `.github/`, `build.gradle`, waghera) us repo mein push kar dein.
3. Push hote hi `.github/workflows/android-build.yml` khud chal jayega aur
   **Actions** tab mein "Android Build" workflow run hoti dikhegi.
4. Run complete hone k baad, run ke andar **Artifacts** section mein
   `BoloEnglish-debug-apk` milega — usay download kar k apne phone par install
   kar k test kar sakte hain.

## 2. Debug APK test karna

- Actions → latest run → Artifacts → `BoloEnglish-debug-apk` download karein.
- Phone mein "Install unknown apps" allow karein us app (browser/files) ke
  liye, phir APK install kar lein.

## 3. Final signed Release APK banana (optional, jab satisfied ho jayein)

Release APK ke liye ek keystore chahiye hoti hai taake app signed ho aur
Play Store ya normal distribution ke liye ready ho.

### Keystore banayein (ek dafa, apne computer par — agar Android Studio
locally install hai to Android Studio se bhi bana sakte hain, warna koi bhi
machine jahan Java ho wahan ye command chalayein):

```
keytool -genkey -v -keystore release.keystore -alias bolo -keyalg RSA -keysize 2048 -validity 10000
```

Isse aapko `alias`, `keystore password`, aur `key password` set karne ko
kaha jayega — inhein yaad rakhein.

### Keystore ko base64 mein convert karein:

```
base64 -w 0 release.keystore > release.keystore.base64.txt
```

(Windows par PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes("release.keystore")) | Out-File release.keystore.base64.txt`)

### GitHub repo mein secrets add karein

Repo → **Settings → Secrets and variables → Actions → New repository secret**:

| Secret name          | Value                                      |
|-----------------------|---------------------------------------------|
| `SIGNING_KEY`          | `release.keystore.base64.txt` ka poora content |
| `KEY_ALIAS`            | wahi alias jo keytool command mein diya tha (e.g. `bolo`) |
| `KEY_STORE_PASSWORD`   | keystore password |
| `KEY_PASSWORD`         | key password |

### Release trigger karna

Ab bas ek version tag push karein:

```
git tag v1.0
git push origin v1.0
```

Ya phir GitHub par **Actions → Android Build → Run workflow** button se
manually bhi chala sakte hain.

Workflow khud signed release APK bana kar:
- Artifact ke taur par upload kar dega (`BoloEnglish-release-apk`)
- Aur ek GitHub **Release** bhi bana kar usme APK attach kar dega (tag push
  ki soorat mein)

## 4. Agar signing secrets set nahi kiye

Agar aap koi secrets set kiye bagair hi "Run workflow" chalayenge to signing
step fail ho jayegi — is soorat mein sirf debug APK use karein jab tak
keystore set-up na kar lein. Debug APK bhi poori tarah functional hoti hai,
bas Play Store publish nahi ki ja sakti (aur update karte waqt naye debug
build se overwrite ho sakti hai).

## App ke baare mein

- Poori app single HTML file (`app/src/main/assets/index.html`) k andar hai
  — jo kuch bhi content ya style change karna ho, wahi file edit karein,
  phir dobara push kar dein.
- `app/src/main/java/com/boloenglish/app/MainActivity.java` sirf ek WebView
  load karta hai — koi extra native logic nahi hai.
- Package name: `com.boloenglish.app` (agar change karna ho to
  `app/build.gradle` ka `applicationId`/`namespace` aur manifest update
  karein).
