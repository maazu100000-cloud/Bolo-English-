# Add project specific ProGuard rules here.
-keepclassmembers class com.boloenglish.app.MainActivity$WebAppInterface {
    public *;
}
